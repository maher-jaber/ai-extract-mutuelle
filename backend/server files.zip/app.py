from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import uuid
import json
from main import GeneralizedOCRProcessor
from flask import render_template
from flasgger import Swagger
import torch
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import timedelta
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_refresh_token

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}}, supports_credentials=True)  # Active CORS pour toutes les routes

swagger_template = {
    "swagger": "2.0",
    "info": {
        "title": "OCR API",
        "description": "API avec JWT pour OCR",
        "version": "1.0"
    },
    "securityDefinitions": {
        "Bearer": {
            "type": "apiKey",
            "name": "Authorization",
            "in": "header",
            "description": "JWT Authorization header using the Bearer scheme. Exemple: 'Bearer {token}'"
        }
    }
}

swagger = Swagger(app, template=swagger_template)  # Active Swagger
# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg', 'tiff', 'bmp'}
app.config['JWT_SECRET_KEY'] = 'Altra@2025'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(minutes=60)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)

jwt = JWTManager(app)
# Configuration SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

jwt = JWTManager(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialisation du processeur OCR
processor = GeneralizedOCRProcessor(lang='fr')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
           
           
           
# Modèle utilisateur
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)           





@app.route('/api/mutuelles', methods=['GET'])
@jwt_required()
def get_mutuelles():
    """
    Récupérer la liste complète des mutuelles
    ---
    tags:
      - Mutuelles
    security:
      - Bearer: []
    responses:
      200:
        description: Liste des mutuelles récupérée avec succès
      500:
        description: Erreur lors de la lecture du fichier
    """
    try:
        with open('mutuelles.json', 'r', encoding='utf-8') as f:
            mutuelles = json.load(f)
        return jsonify(mutuelles)
    except Exception as e:
        return jsonify({'error': f'Erreur lors de la lecture du fichier: {str(e)}'}), 500

@app.route('/api/mutuelles', methods=['POST'])
@jwt_required()
def add_mutuelle():
    """
    Ajouter une nouvelle mutuelle
    ---
    tags:
      - Mutuelles
    security:
      - Bearer: []
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          required:
            - code
            - label
          properties:
            code:
              type: string
              example: "123456789"
            label:
              type: string
              example: "Nouvelle Mutuelle"
    responses:
      201:
        description: Mutuelle ajoutée avec succès
      400:
        description: Données manquantes ou invalides
      500:
        description: Erreur lors de l'écriture du fichier
    """
    try:
        data = request.get_json()
        
        if not data or 'code' not in data or 'label' not in data:
            return jsonify({'error': 'Les champs code et label sont requis'}), 400
        
        # Charger les mutuelles existantes
        try:
            with open('mutuelles.json', 'r', encoding='utf-8') as f:
                mutuelles = json.load(f)
        except FileNotFoundError:
            mutuelles = []
        
        # Vérifier si le code existe déjà
        for mutuelle in mutuelles:
            if mutuelle['code'] == data['code']:
                return jsonify({'error': 'Une mutuelle avec ce code existe déjà'}), 400
        
        # Ajouter la nouvelle mutuelle
        new_mutuelle = {
            'code': data['code'],
            'label': data['label']
        }
        mutuelles.append(new_mutuelle)
        
        # Sauvegarder
        with open('mutuelles.json', 'w', encoding='utf-8') as f:
            json.dump(mutuelles, f, ensure_ascii=False, indent=4)
        
        return jsonify({'message': 'Mutuelle ajoutée avec succès', 'mutuelle': new_mutuelle}), 201
        
    except Exception as e:
        return jsonify({'error': f'Erreur lors de l\'ajout: {str(e)}'}), 500

@app.route('/api/mutuelles/<string:code>', methods=['PUT'])
@jwt_required()
def update_mutuelle(code):
    """
    Modifier une mutuelle existante
    ---
    tags:
      - Mutuelles
    security:
      - Bearer: []
    parameters:
      - name: code
        in: path
        required: true
        type: string
        description: Code de la mutuelle à modifier
      - name: body
        in: body
        required: true
        schema:
          type: object
          properties:
            label:
              type: string
              example: "Mutuelle Modifiée"
    responses:
      200:
        description: Mutuelle modifiée avec succès
      404:
        description: Mutuelle non trouvée
      500:
        description: Erreur lors de la modification
    """
    try:
        data = request.get_json()
        
        if not data or 'label' not in data:
            return jsonify({'error': 'Le champ label est requis'}), 400
        
        # Charger les mutuelles existantes
        with open('mutuelles.json', 'r', encoding='utf-8') as f:
            mutuelles = json.load(f)
        
        # Trouver et modifier la mutuelle
        found = False
        for mutuelle in mutuelles:
            if mutuelle['code'] == code:
                mutuelle['label'] = data['label']
                found = True
                break
        
        if not found:
            return jsonify({'error': 'Mutuelle non trouvée'}), 404
        
        # Sauvegarder
        with open('mutuelles.json', 'w', encoding='utf-8') as f:
            json.dump(mutuelles, f, ensure_ascii=False, indent=4)
        
        return jsonify({'message': 'Mutuelle modifiée avec succès'})
        
    except Exception as e:
        return jsonify({'error': f'Erreur lors de la modification: {str(e)}'}), 500

@app.route('/api/mutuelles/<string:code>', methods=['DELETE'])
@jwt_required()
def delete_mutuelle(code):
    """
    Supprimer une mutuelle
    ---
    tags:
      - Mutuelles
    security:
      - Bearer: []
    parameters:
      - name: code
        in: path
        required: true
        type: string
        description: Code de la mutuelle à supprimer
    responses:
      200:
        description: Mutuelle supprimée avec succès
      404:
        description: Mutuelle non trouvée
      500:
        description: Erreur lors de la suppression
    """
    try:
        # Charger les mutuelles existantes
        with open('mutuelles.json', 'r', encoding='utf-8') as f:
            mutuelles = json.load(f)
        
        # Filtrer pour supprimer la mutuelle
        original_count = len(mutuelles)
        mutuelles = [m for m in mutuelles if m['code'] != code]
        
        if len(mutuelles) == original_count:
            return jsonify({'error': 'Mutuelle non trouvée'}), 404
        
        # Sauvegarder
        with open('mutuelles.json', 'w', encoding='utf-8') as f:
            json.dump(mutuelles, f, ensure_ascii=False, indent=4)
        
        return jsonify({'message': 'Mutuelle supprimée avec succès'})
        
    except Exception as e:
        return jsonify({'error': f'Erreur lors de la suppression: {str(e)}'}), 500

@app.route('/api/mutuelles/search', methods=['GET'])
@jwt_required()
def search_mutuelles():
    """
    Rechercher des mutuelles par terme
    ---
    tags:
      - Mutuelles
    security:
      - Bearer: []
    parameters:
      - name: q
        in: query
        type: string
        required: true
        description: Terme de recherche
    responses:
      200:
        description: Résultats de la recherche
      400:
        description: Paramètre de recherche manquant
      500:
        description: Erreur lors de la recherche
    """
    try:
        search_term = request.args.get('q')
        
        if not search_term:
            return jsonify({'error': 'Le paramètre de recherche (q) est requis'}), 400
        
        # Charger les mutuelles existantes
        with open('mutuelles.json', 'r', encoding='utf-8') as f:
            mutuelles = json.load(f)
        
        # Filtrer les résultats
        results = [
            mutuelle for mutuelle in mutuelles 
            if search_term.lower() in mutuelle['label'].lower() or search_term in mutuelle['code']
        ]
        
        return jsonify(results)
        
    except Exception as e:
        return jsonify({'error': f'Erreur lors de la recherche: {str(e)}'}), 500



@app.route('/api/process', methods=['POST'])
@jwt_required()
def process_document():
    """
    Traiter un document avec OCR
    ---
    tags:
      - OCR
    consumes:
      - multipart/form-data
    parameters:
      - name: file
        in: formData
        type: file
        required: true
        description: Le fichier à traiter (pdf, png, jpg, ...)
    security:
      - Bearer: []
    responses:
      200:
        description: Résultat OCR réussi
        schema:
          type: object
          example: {"text": "Contenu extrait du document"}
      400:
        description: Erreur de fichier fourni ou type non autorisé
      500:
        description: Erreur lors du traitement OCR
    """
    # Vérifier si un fichier a été envoyé
    if 'file' not in request.files:
        return jsonify({'error': 'Aucun fichier fourni'}), 400
    
    file = request.files['file']
    
    # Vérifier si le fichier a un nom
    if file.filename == '':
        return jsonify({'error': 'Aucun fichier sélectionné'}), 400
      
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        
    # Vérifier l'extension du fichier
    if file and allowed_file(file.filename):
        # Générer un nom de fichier unique
        file_id = str(uuid.uuid4())
        file_extension = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{file_id}.{file_extension}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Sauvegarder le fichier
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
        file.save(filepath)
        
        try:
            # Traiter le fichier avec votre OCR
            result = processor.process_file(filepath)
            
            # Nettoyer le fichier uploadé
            if os.path.exists(filepath):
                os.remove(filepath)
                
            return jsonify(result)
            
        except Exception as e:
            # Nettoyer en cas d'erreur
            if os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'error': f'Erreur de traitement: {str(e)}'}), 500
    
    return jsonify({'error': 'Type de fichier non autorisé'}), 400

@app.route('/api/health', methods=['GET'])
def health_check():
    """
    Vérifie si le serveur OCR est opérationnel
    ---
    tags:
      - Santé
    responses:
      200:
        description: Serveur OK
        schema:
          type: object
          example: {"status": "OK", "message": "Serveur OCR opérationnel"}
    """
    return jsonify({'status': 'OK', 'message': 'Serveur OCR opérationnel'})

@app.route('/')
def home():
    return render_template('index.html')
  



@app.route('/api/login', methods=['POST'])
def login():
    """
    Connexion utilisateur pour obtenir un token JWT
    ---
    tags:
      - Auth
    consumes:
      - application/json
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          properties:
            username:
              type: string
              example: admin
            password:
              type: string
              example: password123
    responses:
      200:
        description: Authentification réussie, token JWT généré
        schema:
          type: object
          example: {"access_token": "xxx", "refresh_token": "yyy"}
      401:
        description: Nom d’utilisateur ou mot de passe invalide
    """  
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({'error': 'Données JSON manquantes'}), 400

        username = data.get('username')
        password = data.get('password')
        if not username or not password:
            return jsonify({'error': 'Username et password requis'}), 400

        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            access_token = create_access_token(identity=username)
            refresh_token = create_refresh_token(identity=username)
            return jsonify(access_token=access_token, refresh_token=refresh_token)

        return jsonify({'error': 'Nom d’utilisateur ou mot de passe invalide'}), 401
    except Exception as e:
        return jsonify({'error': f'Erreur interne: {str(e)}'}), 500


@app.route('/api/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """
    Rafraîchir le token d'accès
    ---
    tags:
      - Authentification
    summary: Rafraîche le token d'accès JWT à l'aide du refresh token.
    description: >
      Cette route permet d'obtenir un **nouveau token d'accès** en envoyant un refresh token valide dans l'en-tête **Authorization**.
      Format : `Authorization: Bearer <refresh_token>`
    security:
      - BearerAuth: []
    responses:
      200:
        description: Nouveau token d'accès généré avec succès
        content:
          application/json:
            schema:
              type: object
              properties:
                access_token:
                  type: string
                  example: eyJ0eXAiOiJKV1QiLCJhbGciOi...
      401:
        description: Refresh token invalide ou expiré
    """
    current_user = get_jwt_identity()
    new_access_token = create_access_token(identity=current_user)
    return jsonify(access_token=new_access_token)

if __name__ == "__main__":
  
    with app.app_context():
        db.create_all()
        
        if not User.query.filter_by(username='admin').first():
            admin = User(username='admin')
            admin.set_password('password123')
            db.session.add(admin)
            db.session.commit()
            print("Utilisateur admin créé avec succès !")  
            
    app.run(host='0.0.0.0', port=5000, debug=True)