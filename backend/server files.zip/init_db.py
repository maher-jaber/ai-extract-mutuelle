from app import db, User, app

with app.app_context():
    # Crée toutes les tables définies par les modèles
    db.create_all()
    print("Tables créées (si inexistantes).")
    
    # Crée un admin par défaut si aucun utilisateur n'existe
    if not User.query.filter_by(username='admin').first():
        admin = User(username='admin')
        admin.set_password('password123')
        db.session.add(admin)
        db.session.commit()
        print("Utilisateur admin créé avec succès !")
    else:
        print("Utilisateur admin déjà présent.")
