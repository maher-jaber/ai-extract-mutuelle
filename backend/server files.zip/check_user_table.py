from app import db, User, app
from sqlalchemy import inspect

with app.app_context():
    inspector = inspect(db.engine)
    
    if inspector.has_table('user'):
        print("La table 'user' existe !")
        users = User.query.all()
        if users:
            for u in users:
                print(f"ID: {u.id}, Username: {u.username}")
        else:
            print("Aucun utilisateur trouvé.")
    else:
        print("La table 'user' n'existe pas.")

